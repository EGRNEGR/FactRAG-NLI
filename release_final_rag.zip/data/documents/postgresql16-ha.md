PostgreSQL: Documentation: 16: Chapter 27. High Availability, Load Balancing, and Replication

August 13, 2026: PostgreSQL 18.6, 17.11, 16.15, 15.19, 14.24 and 19 Beta 3 Released!

 Documentation → PostgreSQL 16

 Supported Versions:

 Current
 (18)

 / 

 17

 / 

 16

 / 

 15

 / 

 14

 Development Versions:

 19

 / 
 devel

 Unsupported versions:

 13

 / 
 12

 / 
 11

 / 
 10

 / 
 9.6

 / 
 9.5

 / 
 9.4

 / 
 9.3

 / 
 9.2

 / 
 9.1

 / 
 9.0

 / 
 8.4

 / 
 8.3

 / 
 8.2

 | Chapter 27. High Availability, Load Balancing, and Replication

 | Prev 
 | Up
 | Part III. Server Administration
 | Home
 |  Next

## Chapter 27. High Availability, Load Balancing, and Replication

Table of Contents

 27.1. Comparison of Different Solutions
 27.2. Log-Shipping Standby Servers

 27.2.1. Planning
 27.2.2. Standby Server Operation
 27.2.3. Preparing the Primary for Standby Servers
 27.2.4. Setting Up a Standby Server
 27.2.5. Streaming Replication
 27.2.6. Replication Slots
 27.2.7. Cascading Replication
 27.2.8. Synchronous Replication
 27.2.9. Continuous Archiving in Standby

 27.3. Failover
 27.4. Hot Standby

 27.4.1. User's Overview
 27.4.2. Handling Query Conflicts
 27.4.3. Administrator's Overview
 27.4.4. Hot Standby Parameter Reference
 27.4.5. Caveats

Database servers can work together to allow a second server to take over quickly if the primary server fails (high availability), or to allow several computers to serve the same data (load balancing). Ideally, database servers could work together seamlessly. Web servers serving static web pages can be combined quite easily by merely load-balancing web requests to multiple machines. In fact, read-only database servers can be combined relatively easily too. Unfortunately, most database servers have a read/write mix of requests, and read/write servers are much harder to combine. This is because though read-only data needs to be placed on each server only once, a write to any server has to be propagated to all servers so that future read requests to those servers return consistent results.

This synchronization problem is the fundamental difficulty for servers working together. Because there is no single solution that eliminates the impact of the sync problem for all use cases, there are multiple solutions. Each solution addresses this problem in a different way, and minimizes its impact for a specific workload.

Some solutions deal with synchronization by allowing only one server to modify the data. Servers that can modify data are called read/write, master or primary servers. Servers that track changes in the primary are called standby or secondary servers. A standby server that cannot be connected to until it is promoted to a primary server is called a warm standby server, and one that can accept connections and serves read-only queries is called a hot standby server.

Some solutions are synchronous, meaning that a data-modifying transaction is not considered committed until all servers have committed the transaction. This guarantees that a failover will not lose any data and that all load-balanced servers will return consistent results no matter which server is queried. In contrast, asynchronous solutions allow some delay between the time of a commit and its propagation to the other servers, opening the possibility that some transactions might be lost in the switch to a backup server, and that load balanced servers might return slightly stale results. Asynchronous communication is used when synchronous would be too slow.

Solutions can also be categorized by their granularity. Some solutions can deal only with an entire database server, while others allow control at the per-table or per-database level.

Performance must be considered in any choice. There is usually a trade-off between functionality and performance. For example, a fully synchronous solution over a slow network might cut performance by more than half, while an asynchronous one might have a minimal performance impact.

The remainder of this section outlines various failover, replication, and load balancing solutions.

 | Prev 
 | Up
 |  Next

 | 26.3. Continuous Archiving and Point-in-Time Recovery (PITR) 
 | Home
 |  27.1. Comparison of Different Solutions

## Submit correction

 If you see anything in the documentation that is not correct, does not match
 your experience with the particular feature or requires further clarification,
 please use
 this form
 to report a documentation issue.
